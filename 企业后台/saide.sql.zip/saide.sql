-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2017-11-01 16:49:13
-- 服务器版本： 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saide`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin_column_body`
--

CREATE TABLE `admin_column_body` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `page` smallint(20) NOT NULL,
  `stert` varchar(200) NOT NULL,
  `title` varchar(300) NOT NULL,
  `abstract` varchar(200) NOT NULL,
  `body` varchar(10000) NOT NULL,
  `image` varchar(200) NOT NULL,
  `time` int(10) NOT NULL,
  `updates` int(10) NOT NULL,
  `status` smallint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_column_class`
--

CREATE TABLE `admin_column_class` (
  `id` int(11) NOT NULL,
  `class_title` varchar(200) NOT NULL,
  `pid` int(10) NOT NULL,
  `class_time` int(10) NOT NULL,
  `class_update` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_feedback`
--

CREATE TABLE `admin_feedback` (
  `id` int(11) NOT NULL,
  `full_name` varchar(20) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_feedback_contact`
--

CREATE TABLE `admin_feedback_contact` (
  `id` int(11) NOT NULL,
  `contacts` varchar(5) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` int(10) NOT NULL,
  `updates` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_image`
--

CREATE TABLE `admin_image` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(300) NOT NULL,
  `source` varchar(300) NOT NULL,
  `abstract` varchar(300) NOT NULL,
  `image` varchar(300) NOT NULL,
  `time` int(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_information`
--

CREATE TABLE `admin_information` (
  `id` int(11) NOT NULL,
  `uid` int(10) NOT NULL,
  `information_page` int(10) NOT NULL,
  `information_image` varchar(200) NOT NULL,
  `information_title` varchar(500) NOT NULL,
  `information_body` varchar(10000) NOT NULL,
  `information_abstract` varchar(500) NOT NULL,
  `information_time` int(10) NOT NULL,
  `information_update` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `source` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_information_cate`
--

CREATE TABLE `admin_information_cate` (
  `id` int(11) NOT NULL,
  `pid` int(10) NOT NULL,
  `cate_title` varchar(200) NOT NULL,
  `cate_time` int(10) NOT NULL,
  `cate_update` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_name`
--

CREATE TABLE `admin_name` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `role` smallint(10) NOT NULL,
  `time` int(10) NOT NULL,
  `status` smallint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `admin_system_base`
--

CREATE TABLE `admin_system_base` (
  `id` int(11) NOT NULL,
  `base_title` varchar(100) NOT NULL,
  `base_copyright` varchar(100) NOT NULL,
  `base_address` varchar(200) NOT NULL,
  `base_record_number` varchar(100) NOT NULL,
  `base_time` int(10) NOT NULL,
  `base_update` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `admin_system_base`
--

INSERT INTO `admin_system_base` (`id`, `base_title`, `base_copyright`, `base_address`, `base_record_number`, `base_time`, `base_update`) VALUES
(1, '', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `admin_user`
--

CREATE TABLE `admin_user` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` smallint(10) NOT NULL,
  `date_time` int(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `admin_user`
--

INSERT INTO `admin_user` (`id`, `name`, `password`, `role`, `date_time`, `status`) VALUES
(1, 'saide', '111023', 1, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_column_body`
--
ALTER TABLE `admin_column_body`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_column_class`
--
ALTER TABLE `admin_column_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_feedback`
--
ALTER TABLE `admin_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_feedback_contact`
--
ALTER TABLE `admin_feedback_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_image`
--
ALTER TABLE `admin_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_information`
--
ALTER TABLE `admin_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_information_cate`
--
ALTER TABLE `admin_information_cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_name`
--
ALTER TABLE `admin_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_system_base`
--
ALTER TABLE `admin_system_base`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `admin_column_body`
--
ALTER TABLE `admin_column_body`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- 使用表AUTO_INCREMENT `admin_column_class`
--
ALTER TABLE `admin_column_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `admin_feedback`
--
ALTER TABLE `admin_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `admin_feedback_contact`
--
ALTER TABLE `admin_feedback_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `admin_image`
--
ALTER TABLE `admin_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `admin_information`
--
ALTER TABLE `admin_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `admin_information_cate`
--
ALTER TABLE `admin_information_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `admin_name`
--
ALTER TABLE `admin_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `admin_system_base`
--
ALTER TABLE `admin_system_base`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
